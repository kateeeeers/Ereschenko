<?
$sql = '';
$ar_result = [];
$mysqli = new mysqli('localhost', 'root', '', 'sokolov');
if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}
$sql = "SELECT Name, Description, Price,ImageLink FROM goods";
$result = mysqli_query($mysqli,$sql);

while ($row = mysqli_fetch_array($result)){
	$ar_result[] = $row;
	
}
?>

<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>sokolov.ru</title>
  </head>
  <body>
    <script src="https://kit.fontawesome.com/e37c9c6522.js" crossorigin="anonymous"></script>
    <div class="header">
      <div class="nav-menu">
        <div class="container">
          <div class="nav__row">
            <div class="nav__left">
              <div class="nav__location">
                <a href="#">Волгоград</a>
              </div>
              <div class="nav__number">
                8 800 1000 750
              </div>
            </div>
            <div class="nav__right">
              <nav class="navbar navbar-expand-xl navbar-light">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <a href="#" class="linkiconspace"><i class="fas fa-search"></i></a><a href="#" class="linkiconspace"><i class="fas fa-camera"></i></a>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                  <ul class="navbar-nav">
                    <li class="nav-item active">
                      <a class="nav-link" href="#"><i class="far fa-gem"> </i> Украшения на заказ</a>
                    </li>
                    <li class="nav-item active">
                      <a class="nav-link" href="#">Доставка и оплата</a>
                    </li>
                    <li class="nav-item active">
                      <a class="nav-link" href="#">Магазины</a>
                    </li>
                    <li class="nav-item active">
                      <a class="nav-link" href="#">mySOKOLOV</a>
                    </li>
                    <li class="nav-item active">
                      <a class="nav-link" href="#">Журнал</a>
                    </li>
                    <li class="nav-item active">
                      <a class="nav-link" href="#">Вакансии</a>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="header__about">
          <div class="header__row">
            <div class="header__left">
              <div class="header__item">
                <a href="#">АКЦИИ</a>
              </div>
              <div class="header__item">
                <a href="#">НОВИНКИ</a>
              </div>
              <div class="header__item">
                <a href="#">SALE</a>
              </div>
            </div>
            <div class="header__logo">
              <a href="#"><img src="image/image/sokolov-logo_ru.svg" alt=""></a>
            </div>
            <div class="header__right">
              <div class="header__item">
                <a href="#">ВОЙТИ</a>
              </div>
              <div class="header__item">
                <a href="#"><i class="far fa-heart"></i></a>
              </div>
              <div class="header__item">
                <a href="#"><i class="fas fa-shopping-cart"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="menu">
      <div class="container">
        <div class="menu__row">
          <div class="menu__left">
            <div class="input-group">
              <button type="button" class="btn btn-primary btn-search">
                <i class="fas fa-search"></i>
              </button>
              <div class="form-outline">
                <input type="search" id="form1" placeholder="Поиск" class="form-control" />
              </div>
            </div>
            <a href="#"><i class="fas fa-camera"></i></a>
          </div>
          <div class="menu__right">
            <div class="menu__item">
              <a href="#">УКРАШЕНИЯ</a>
            </div>
            <div class="menu__item">
              <a href="#">БРИЛЛИАНТЫ</a>
            </div>
            <div class="menu__item">
              <a href="#">ПОМОЛВКА И СВАДЬБА</a>
            </div>
            <div class="menu__item">
              <a href="#">SOKOLOV</a>
            </div>
            <div class="menu__item">
              <a href="#">DIAMONDS</a>
            </div>
            <div class="menu__item">
              <a href="#">КОЛЛЕКЦИИ</a>
            </div>
            <div class="menu__item">
              <a href="#">SKLV</a>
            </div>
            <div class="menu__item">
              <a href="#">ЧАСЫ</a>
            </div>
            <div class="menu__item">
              <a href="#">ПОДАРКИ</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="local-link">
      <div class="container">
        <div class="local__item">
          <a href="#"><i class="fas fa-home"></i></a> <i class="fas fa-chevron-right"></i><a href="#"><i class="fas fa-ellipsis-h"></i></a><i class="fas fa-chevron-right"></i> <a href="#">Серьги из белого золота
          </a> <i class="fas fa-chevron-right"></i>Серьги из белого золота с бриллиантами
        </div>
      </div>
    </div>
    <div class="goods">
      <div class="container"> 
      <div class="row">
        <div class="col-12 col-lg-7">
          <div class="goods__row">
            <div class="goods__mini">
              <div>
                <a href="#"><img src="image/image/1.jpg" alt=""></a>
              </div>
              <div>
                <a href="#"><img src="image/image/2.jpg" alt=""></a>
              </div>
              <div>
                <a href="#"><img src="image/image/3.jpg" alt=""></a>
              </div>
              <div>
                <a href="#"><img src="image/image/4.jpg" alt=""></a>
              </div>
              <div>
                <a href="#"><img src="image/image/5.jpg" alt=""></a>
              </div>
            </div>
            <div class="goods__big">
              <a href="#"><img src="image/image/bigphoto.jpg" alt=""></a>
            </div>
          </div>
        </div>
        <div class="col-12 col-lg-5">
          <div class="raiting">
            <a href="#"><i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i></a> <a href="#">26 отзывов</a>
          </div>
          <div class="name">
            Серьги из белого золота с бриллиантами
          </div>
          <div class="art">
            Артикул: 1021314
          </div>
          <div class="price">
            <strong>36 500 ₽</strong> <span>72 990 ₽</span> <i class="fas fa-exclamation-circle"></i>
          </div>
          <div class="bonus">
            <strong>+ 7 300 БР</strong> за покупку   <span><i class="fas fa-exclamation-circle"></i></span>
          </div>
          <div class="buttons">
            <button type="button" class="btn btn-dark rounded-0"><strong>- 5%</strong> НА ЗОЛОТО</button><button type="button" class="btn btn-light rounded-0">ПОЛУЧИТЬ</button>
          </div>
          <div class="buy">
            <button type="button" class="btn btn-dark"><strong>+ КУПИТЬ</strong></button>
          </div>
          <div class="goods-navs">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item" role="presentation">
                <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">ДОСТАВКА</a>
              </li>
              <li class="nav-item" role="presentation">
                <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">ОПЛАТА</a>
              </li>
              <li class="nav-item" role="presentation">
                <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">ГАРАНТИЯ И ВОЗВРАТ</a>
              </li>
            </ul>
            <div class="tab-content" id="myTabContent">
              <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div class="div1"> <br>
                  Ваш город: <a href="#">Волгоград</a> <br> <br>
                </div>
                <div class="div2">
                  <a href="#" class="green"><i class="fas fa-check"></i> Бесплатная доставка</a> <a href="#" class="green"><i class="fas fa-check"></i> Примерка товара перед покупкой</a> <br> <br>
                </div>
                <div class="div3">
                  <i class="fas fa-store-alt"></i> <a href="#">В наличии в 2 магазинах</a> <br> Забрать завтра, бесплатно <br><br>
                  <i class="fas fa-truck"></i> <a href="#">Курьерская доставка</a><br> 24-25 ноября, бесплатно <br><br>
                  <i class="fas fa-box-open"></i> <a href="#">Самовывоз из 249 пунктов выдачи</a><br> 23-24 ноября, бесплатно <br><br>
                  <a href="#">Подробнее о доставке</a>
                </div>
              </div>
              <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="div4"> <br>
                  В зависимости от выбранного способа доставки доступны следующие варианты оплаты заказа: <br>
                  <br>
                  <i class="fas fa-circle"></i> Картой онлайн <br> <br>
                  <i class="fas fa-circle"></i> Бонусами СПАСИБО от Сбербанка <br>
                  Бонусами СПАСИБО можно оплатить до 99% заказа. <br> <br>
                  <i class="fas fa-circle"></i> Наличными или картой при получении <br><br>
                  Для заказов с доставкой из партнёрских магазинов и самовывозом из флагманских магазинов SOKOLOV доступна только оплата при получении.
                </div>
              </div>
              <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="div5"> <br>
                  Гарантийный срок для всех товаров за исключением часов составляет 6 месяцев. Для часов из стали установлен гарантийный срок в течение 1 года с момента покупки, для ювелирных часов – 3 года. <br> <br>

                  Возврат ювелирных изделий надлежащего качества возможен при условии сохранения их товарного вида и потребительских свойств. В случае дистанционного приобретения изделий отказ от заказа доступен в любое время до его передачи и в течение 7 дней после. <br> <br>

                  В случае обнаружения брака покупатель может отправить заявку на возврат по электронной почте. Заявка рассматривается 3 рабочих дня. <br> <br> <a href="#">Подробнее о доставке</a>
                </div>
              </div>
            </div>
          </div>
          <div class="goods-about">
            <div>
              Материал <br> <br>
              Примерный вес <br> <br>
              Вставка <br> <br>
            </div>
            <div>
              Белое золото 585 пробы <br> <br>
              2.68 г <br> <br>
              Бриллиант (2 шт, 0.076 карат) <br> <br>
            </div>
          </div>
          <a href="#">Все характеристики</a>
        </div>
      </div>
      </div>
    </div>
    <div class="variants">
      <div class="title">
        ВАМ МОЖЕТ ПОНРАВИТЬСЯ
      </div>
	  <div class = "row">
      <?
foreach ($ar_result as $value){
	echo '<div class="card text-black  mb-3 border-white" style="max-width: 18rem; margin-left:6%; border-color: white);" >
  <div class="header" style="background: white; display: block;" align="center"><img src="'.$value[ImageLink].'" style="width: 65%; height: 100%;"></img></div>
  <div class="card-body" style = "height:auto;background: white;">
    <h5 class="card-title">'.$value[Name].'</h5>
    <p class="card-text">'.$value[Description].'</p>
	<p class="card-text">'.$value[Price].'</p>
  </div>
</div>';
	
}
?>
</div>
    </div>
    <div class="variants">
      <div class="title">
        ДОПОЛНИТЕ СВОЙ ОБРАЗ
      </div>
      <div class="cards">
        <a href="#">
          <div class="card" style="width: 18rem;">
            <i class="far fa-heart flexright"></i>
            <img src="image/image/33.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">36 500 Р <span>72 990 Р</span></h5>
              <p class="card-text">
                Серьги из белого золота с бриллиантами            </p>
            </div>
            <a href="#" class="btn btn-dark zakazat">ЗАКАЗАТЬ</a>
          </div>
        </a>
        <a href="#">
          <div class="card" style="width: 18rem;">
            <i class="far fa-heart flexright"></i>
            <img src="image/image/44.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">30 250 Р <span>60 490 Р</span></h5>
              <p class="card-text">
                Кольцо из белого золота 585 пробы с бриллиантами            </p>
            </div>
            <a href="#" class="btn btn-dark zakazat">ЗАКАЗАТЬ</a>
          </div>
        </a>
      </div>
    </div>
    <div class="bottom">
        <div class="row justify-content-center">
          <div class="left col-12 col-sm-4 col-md-3 col-lg-4 f-flex text-center">
            <a href="#">8 800 1000 750</a> <br>
            © 2021 SOKOLOV
          </div>
          <div class="col-12 col-sm-8 col-md-6 col-lg-4 d-flex row text-center">
            <div class="col-12 col-sm-4 icons-bottom mt-2 mt-sm-0 ">
              <a href="#"><img src="image/image/1.svg" alt=""></a>
            </div>
            <div class="col-12 col-sm-4  icons-bottom mt-2 mt-sm-0">
              <a href="#"><img src="image/image/2.svg" alt=""></a>
            </div>
            <div class="col-12 col-sm-4 icons-bottom mt-2 mt-sm-0">
              <a href="#"><img src="image/image/3.svg" alt=""></a>
            </div>
          </div>
          <div class="right col-12 col-md-3 col-lg-4 f-flex text-center text-md-end mt-2 mt-sm-0">
            <a href="#"><i class="fas fa-play"></i></a> <a href="#"><i class="fab fa-vk"></i></a><a href="#"><i class="fab fa-facebook-square"></i></a><a href="#"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  </body>
</html>